﻿using eShopSolution.ViewModels.Catalog.Products;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eShopSolution.WebApp.Models
{
    public class ViewProductByCategoryViewModel
    {
        List<ProductViewModel> Products { get; set; }
    }
}

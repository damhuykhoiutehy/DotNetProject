﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eShopSolution.ViewModels.Utilities.Enums
{
    public enum  Status
    {
        InActive,
        Active
    }
}

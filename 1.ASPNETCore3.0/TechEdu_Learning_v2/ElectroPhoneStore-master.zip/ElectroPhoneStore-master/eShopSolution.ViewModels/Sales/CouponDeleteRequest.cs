﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eShopSolution.ViewModels.Sales
{
    public class CouponDeleteRequest
    {
        public int Id { get; set; }
    }
}
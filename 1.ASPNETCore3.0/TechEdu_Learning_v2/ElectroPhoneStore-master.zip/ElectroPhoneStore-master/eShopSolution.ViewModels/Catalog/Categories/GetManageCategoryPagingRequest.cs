﻿using eShopSolution.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace eShopSolution.ViewModels.Catalog.Categories
{
    public class GetManageCategoryPagingRequest 
    {
        public string LanguageId { get; set; }
    }
}

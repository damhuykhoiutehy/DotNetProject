﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eShopSolution.ViewModels.System.Languages
{
    public class LanguageViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }

    }
}

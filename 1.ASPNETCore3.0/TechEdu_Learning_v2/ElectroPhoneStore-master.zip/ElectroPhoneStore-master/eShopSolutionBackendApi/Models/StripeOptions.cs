﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eShopSolutionBackendApi.Models
{
    public class StripeOptions
    {
        public string option { get; set; }
    }
}
